import { authenticate } from "../models/userModel.js";

export function renderLogin() {
  fetch("views/loginView.html")
    .then((res) => res.text())
    .then((html) => {
      document.getElementById("app").innerHTML = html;
      attachLoginListeners();
    });
}

function attachLoginListeners() {
  const loginButton = document.querySelector(".btn-primary");

  loginButton.addEventListener("click", () => {
    const email = document.querySelector("input[type='email']").value.trim();
    const password = document.querySelector("input[type='password']").value.trim();

    if (!email || !password) {
      alert("Email dan password harus diisi!");
      return;
    }

    const user = authenticate(email, password);

    if (user) {
      alert(`Selamat datang, ${user.name}!`);
      sessionStorage.setItem("isLoggedIn", true); // Persist login state
      console.log("Login successful, isLoggedIn set to true"); // Log the login action
      window.loadView("curhat"); // Redirect to Curhat
    } else {
      alert("Email atau password salah. Silakan coba lagi.");
    }
  });
}
