export function renderCurhat() {
  fetch("views/curhat.html")
    .then((res) => res.text())
    .then((html) => {
      document.getElementById("app").innerHTML = html;

      const submitButton = document.getElementById("submitCurhat");
      const curhatInput = document.getElementById("curhatInput");
      const result = document.getElementById("result");

      submitButton.addEventListener("click", async () => {
        const text = curhatInput.value.trim();

        if (!text) {
          result.textContent = "Please enter your thoughts before submitting.";
          result.style.color = "red";
          return;
        }

        try {
          const response = await fetch("http://localhost:5001/api/curhat", {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
            },
            body: JSON.stringify({ text }),
          });

          if (!response.ok) {
            throw new Error("Failed to submit curhat");
          }

          const data = await response.json();
          console.log("Backend response:", data); // Log the backend response

          // Redirect to the Feedback page
          window.loadView("feedback");
        } catch (error) {
          console.error("Error submitting curhat:", error);
          result.textContent = "There was an error communicating with the backend.";
          result.style.color = "red";
        }
      });
    });
}
