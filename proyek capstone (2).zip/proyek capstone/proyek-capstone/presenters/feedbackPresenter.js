export function renderFeedback() {
  fetch("views/feedbackView.html")
    .then((res) => res.text())
    .then((html) => {
      document.getElementById("app").innerHTML = html;

      // Fetch the latest submissions from the backend
      fetch("http://localhost:5001/api/submissions")
        .then((res) => res.json())
        .then((submissions) => {
          const latestSubmission = submissions[submissions.length - 1]; // Get the latest submission
          console.log("Latest submission retrieved from backend:", latestSubmission);

          // Display the analysis
          document.getElementById("analysis-text").textContent = latestSubmission.analysis;

          // Display the keywords
          const keywordList = document.getElementById("keyword-list");
          latestSubmission.keywords.forEach((word) => {
            const li = document.createElement("li");
            li.textContent = word;
            keywordList.appendChild(li);
          });

          // Display the stress level percentage
          document.querySelector(".percentage").textContent = `${latestSubmission.stressLevel}%`;
        })
        .catch((error) => {
          console.error("Error fetching submissions from backend:", error);
        });
    });
}
