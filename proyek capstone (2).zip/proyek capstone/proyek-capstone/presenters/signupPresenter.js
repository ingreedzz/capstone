import { saveUser, userExists } from "../models/userModel.js";

export function renderSignup() {
  fetch("views/signupView.html")
    .then((res) => res.text())
    .then((html) => {
      document.getElementById("app").innerHTML = html;
      attachSignupListeners();
    });
}

function attachSignupListeners() {
  const signupButton = document.getElementById("signupButton");

  signupButton.addEventListener("click", () => {
    const name = document.getElementById("signupName").value.trim();
    const email = document.getElementById("signupEmail").value.trim();
    const password = document.getElementById("signupPassword").value.trim();

    if (!name || !email || !password) {
      alert("All fields are required!");
      return;
    }

    if (userExists(email)) {
      alert("Email is already registered. Please use another email.");
      return;
    }

    saveUser({ name, email, password });
    alert("Sign up successful! Redirecting to login.");
    loadView("login"); 
  });
}
