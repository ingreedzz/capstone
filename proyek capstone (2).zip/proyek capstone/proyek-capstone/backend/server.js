import express from "express";
import cors from "cors";
import path from "path";
import { fileURLToPath } from "url";

const app = express();
const PORT = 5001; // Use a different port to avoid conflicts with Vite (frontend)

// Define __dirname for ES modules
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Middleware
app.use(cors());
app.use(express.json());

// Set EJS as the view engine
app.set("view engine", "ejs");
app.set("views", path.join(__dirname, "views")); // Set the views directory

const curhatStorage = []; // Temporary in-memory storage

// Function to verify submission data
function verifySubmission(submission) {
  console.log("Verifying submission:", submission); // Log the submission being verified

  if (!submission || typeof submission !== "object") {
    console.log("Verification failed: Invalid submission format.");
    return { valid: false, error: "Invalid submission format." };
  }

  if (!submission.text || typeof submission.text !== "string" || submission.text.trim() === "") {
    console.log("Verification failed: Text is required and must be a non-empty string.");
    return { valid: false, error: "Text is required and must be a non-empty string." };
  }

  if (!Array.isArray(submission.keywords)) {
    console.log("Verification failed: Keywords must be an array.");
    return { valid: false, error: "Keywords must be an array." };
  }

  if (typeof submission.stressLevel !== "number" || submission.stressLevel < 0 || submission.stressLevel > 100) {
    console.log("Verification failed: Stress level must be a number between 0 and 100.");
    return { valid: false, error: "Stress level must be a number between 0 and 100." };
  }

  console.log("Verification passed.");
  return { valid: true };
}

// Route to return submissions as JSON (for frontend)
app.get("/api/submissions", (req, res) => {
  console.log("Fetching all submissions...");
  console.log("Current storage:", curhatStorage); // Log the current storage

  const invalidSubmissions = curhatStorage.filter((submission) => !verifySubmission(submission).valid);

  if (invalidSubmissions.length > 0) {
    console.error("Invalid submissions found:", invalidSubmissions);
    return res.status(500).json({ error: "Invalid data found in storage." });
  }

  console.log("All submissions are valid. Returning submissions.");
  res.json(curhatStorage); // Return all stored submissions as JSON
});

// Route to render submissions in HTML (for debugging)
app.get("/", (req, res) => {
  res.render("submissions", { submissions: curhatStorage }); // Render the EJS template
});

// Route to handle curhat submissions
app.post("/api/curhat", (req, res) => {
  const { text } = req.body;

  console.log("Received curhat from frontend:", text);

  if (!text) {
    return res.status(400).json({ error: "Text is required" });
  }

  const keywords = ["stress", "anxious", "tired"];
  const matchedKeywords = keywords.filter((keyword) =>
    text.toLowerCase().includes(keyword)
  );

  const curhatData = {
    text,
    analysis: "Simulated analysis based on your input.",
    keywords: matchedKeywords,
    stressLevel: Math.floor(Math.random() * 60) + 40,
  };

  // Verify the submission
  const verification = verifySubmission(curhatData);
  if (!verification.valid) {
    return res.status(400).json({ error: verification.error });
  }

  curhatStorage.push(curhatData); // Store the data in memory
  console.log("Current storage:", curhatStorage); // Log the storage

  res.json(curhatData);
});

// Start the server
app.listen(PORT, () => {
  console.log(`Backend server is running on http://localhost:${PORT}`);
});