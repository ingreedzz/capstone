import { renderHome } from './presenters/homePresenter.js';
import { renderLogin } from './presenters/loginPresenter.js';
import { renderSignup } from './presenters/signupPresenter.js';
import { renderCurhat } from './presenters/curhatPresenter.js';
import { renderFeedback } from './presenters/feedbackPresenter.js';

window.loadView = function(view) {
  const isLoggedIn = JSON.parse(sessionStorage.getItem("isLoggedIn")) || false; // Always retrieve the latest state
  console.log(`Attempting to load view: ${view}`); // Log the view being loaded
  console.log(`isLoggedIn: ${isLoggedIn}`); // Log the current login state
  switch (view) {
    case 'home':
      renderHome();
      break;
    case 'login':
      renderLogin();
      break;
    case 'signup':
      renderSignup();
      break;
    case 'curhat':
      if (isLoggedIn) {
        renderCurhat();
      } else {
        renderLogin(); 
      }
      break;
    case 'feedback':
      if (isLoggedIn) {
        renderFeedback();
      } else {
        renderLogin();
      }
      break;
    default:
      renderHome();
  }
};

window.login = function() {
  isLoggedIn = true; // Update the global variable
  sessionStorage.setItem("isLoggedIn", true); // Persist login state
  console.log("User logged in, isLoggedIn set to true"); // Log the login action
  loadView('curhat'); // Redirect to Curhat
};

window.logout = function() {
  sessionStorage.removeItem("isLoggedIn"); // Clear login state from sessionStorage
  console.log("User logged out, isLoggedIn set to false"); // Log the logout action

  // Update the visibility of the buttons
  const logoutLink = document.querySelector("a[onclick='logout()']");
  const loginLink = document.querySelector("a[onclick=\"loadView('login')\"]");

  logoutLink.style.display = "none"; // Hide Logout
  loginLink.style.display = "inline"; // Show Login

  loadView("home"); // Redirect to Home
};

window.addEventListener("DOMContentLoaded", () => {
  const isLoggedIn = JSON.parse(sessionStorage.getItem("isLoggedIn")) || false; // Retrieve login state
  console.log(`DOMContentLoaded: isLoggedIn = ${isLoggedIn}`); // Log the login state on page load

  const logoutLink = document.querySelector("a[onclick='logout()']");
  const loginLink = document.querySelector("a[onclick=\"loadView('login')\"]");

  if (isLoggedIn) {
    logoutLink.style.display = "inline"; // Show Logout
    loginLink.style.display = "none"; // Hide Login
    loadView("curhat"); // Redirect to Curhat if logged in
  } else {
    logoutLink.style.display = "none"; // Hide Logout
    loginLink.style.display = "inline"; // Show Login
    loadView("home"); // Redirect to Home if not logged in
  }
});
